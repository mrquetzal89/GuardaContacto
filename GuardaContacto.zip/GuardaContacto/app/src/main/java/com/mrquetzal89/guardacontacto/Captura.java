package com.mrquetzal89.guardacontacto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

public class Captura extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_captura);
    }

    public void irSiguiente(View v){
        EditText edtNombre = (EditText) findViewById(R.id.edtNombre);
        String nombre = edtNombre.getText().toString();
        DatePicker dpCumple = (DatePicker) findViewById(R.id.dpCumple);
        int anio = dpCumple.getYear();
        int mes = dpCumple.getMonth();
        int dia = dpCumple.getDayOfMonth();
        EditText edtTelefono = (EditText) findViewById(R.id.edtTelefono);
        String telefono = edtTelefono.getText().toString();
        EditText edtCorreo = (EditText) findViewById(R.id.edtCorreo);
        String correo = edtCorreo.getText().toString();
        EditText edtObservaciones = (EditText) findViewById(R.id.edtObservaciones);
        String observaciones = edtObservaciones.getText().toString();


        Intent intent = new Intent(this, ConfirmarDatos.class);
        intent.putExtra(getString(R.string.key_param_nombre_usuario),nombre);
        intent.putExtra(getString(R.string.key_param_telefono_usuario),telefono);
        intent.putExtra(getString(R.string.key_param_correo_usuario),correo);
        intent.putExtra(getString(R.string.key_param_observaciones_usuario),observaciones);
        intent.putExtra(getString(R.string.key_param_anio_usuario),anio);
        intent.putExtra(getString(R.string.key_param_mes_usuario),mes);
        intent.putExtra(getString(R.string.key_param_dia_usuario),dia);
        startActivity(intent);
    }
}
