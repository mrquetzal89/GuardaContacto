package com.mrquetzal89.guardacontacto;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;

public class ConfirmarDatos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_datos);
        Bundle extras = getIntent().getExtras();
        String nombre = extras.getString(getString(R.string.key_param_nombre_usuario));
        TextView tvNombre = (TextView) findViewById(R.id.tvNombre);
        tvNombre.append(nombre);
        //
        int anio = extras.getInt(getString(R.string.key_param_anio_usuario));
        int mes = extras.getInt(getString(R.string.key_param_mes_usuario));
        int dia = extras.getInt(getString(R.string.key_param_dia_usuario));
        TextView tvCumple = (TextView) findViewById(R.id.tvCumple);
        tvCumple.append(anio+"/"+mes+"/"+dia);
        //
        String telefono = extras.getString(getString(R.string.key_param_telefono_usuario));
        TextView tvTelefono = (TextView) findViewById(R.id.tvTelefono);
        tvTelefono.append(telefono);
        //
        String correo = extras.getString(getString(R.string.key_param_correo_usuario));
        TextView tvCorreo = (TextView) findViewById(R.id.tvCorreo);
        tvCorreo.append(correo);
        //
        String observaciones = extras.getString(getString(R.string.key_param_observaciones_usuario));
        TextView tvObservaciones = (TextView) findViewById(R.id.tvObservaciones);
        tvObservaciones.append(observaciones);
    }

    public void regresar(View v) {
        finish();
    }

}
